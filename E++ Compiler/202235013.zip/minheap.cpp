/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "minheap.h"
//Write your code below this line

MinHeap::MinHeap(){
    size=0;
    root=NULL;
}
void swap(HeapNode*& a,HeapNode*& b){
    int temp{a->val};
    a->val=b->val;
    b->val=temp;
}
void MinHeap::push_heap(int num){
    HeapNode* newnode=new HeapNode(num);
    this->size++;
    HeapNode* current=root;
    if (root==NULL){
        root=newnode;
        return;
    }
    int h{1},hsize{this->size};
    while(this->size-(2*h)>=0) h*=2;
    hsize-=h;
    h/=2;
    while(h>1){
        if (hsize>=h){
            current=current->right;
            hsize-=h;
            h/=2;
        }else{
            current=current->left;
            h/=2;
        }
    }
    newnode->par=current;
    if (current->left==NULL) current->left=newnode;
    else current->right=newnode;
    current=newnode;

    while(current->par){
        if (current->par->val>current->val){
            swap(current,current->par);
            current=current->par;
        }else break;
    }
}

int MinHeap::get_min(){
    return this->root->val;
}

void MinHeap::pop(){
    if (root==NULL) return;
    if (this->size==1){
        delete root;
        root=NULL;
        size=0;
        return;
    }
    HeapNode* current=root;
    int h{1},hsize{this->size+1};
    while(1+this->size-(2*h)>0) h*=2;
    hsize-=h;
    h/=2;
    while(h>=1){
        if (hsize>h){
            current=current->right;
            hsize-=h;
            h/=2;
        }else{
            current=current->left;
            h/=2;
        }
    }
    root->val=current->val;
    if (current->par->left==current)current->par->left=NULL;
    else current->par->right=NULL;
    delete current;
    this->size--;
    current=root;
    while(current){
        if (current->left and current->right){
            if (current->left->val<current->right->val){
                if (current->val>current->left->val)
                {swap(current,current->left);
                current=current->left;}
                else break;
            }else{
                if (current->val>current->right->val)
                {swap(current,current->right);
                current=current->right;}
                else break;
            }
        }else if (current->left){
            if (current->left->val<current->val) 
            {swap(current,current->left);
            current=current->left;}
            else break;
        }else if (current->right){
            if (current->right->val<current->val) 
            {swap(current,current->right);
            current=current->right;}
            else break;
        }else break;
    }
}

MinHeap::~MinHeap(){
    delete root;
    this->size=0;
}
