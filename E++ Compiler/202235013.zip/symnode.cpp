/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "symnode.h"

//Write your code below this line
SymNode::SymNode(){
    key="";
    height=0;
}

SymNode::SymNode(string k){
    key=k;
    height=0;
}
int ht(SymNode* node){
    if (node) return node->height;
    else return -1;
}
//     z            y
//    /            / \
//   y      =>    x   z   
//  / \              /
// x   t            t
SymNode* SymNode::RightRightRotation(){
    // this is z
    SymNode* y=this->left;
    SymNode* t=y->right;
    SymNode* temp=this->par;
    // update parents
    if (temp){
        if (this->key<(temp->key)) temp->left=y;
        else temp->right=y;
    }
    this->par=y;
    y->par=temp;
    if (t) t->par=this;
    // rotate
    y->right=this;
    this->left=t;
    // update height
    this->height=1+max(ht(this->left),ht(this->right));
    y->height=1+max(ht(y->left),ht(y->right));
    // return root
    return y;
}
// z                y
//  \              / \
//   y      =>    z   x
//  / \            \
// t   x            t
SymNode* SymNode::LeftLeftRotation(){
    SymNode* y=this->right;
    SymNode* t=y->left;
    SymNode* temp=this->par;
    // update parents
    if (temp){
        if (this->key<(temp->key)) temp->left=y;
        else temp->right=y;
    }
    this->par=y;
    y->par=temp;
    if (t) t->par=this;
    // rotate
    y->left=this;
    this->right=t;
    // update height
    this->height=1+max(ht(this->left),ht(this->right));
    y->height=1+max(ht(y->left),ht(y->right));
    // return root
    return y;
}
//     z            
//    /        
//   y     
//  / \
// t   x
SymNode* SymNode::LeftRightRotation(){
    SymNode* y=this->left;
    y->LeftLeftRotation();
    return this->RightRightRotation();
}
// z
//  \
//   y
//  / \
// x   t
SymNode* SymNode::RightLeftRotation(){
    SymNode* y=this->right;
    y->RightRightRotation();
    return this->LeftLeftRotation();
}

SymNode::~SymNode(){
    delete (this->left);
    left=NULL;
    delete (this->right);
    right=NULL;
    key="";
    height=0;
}