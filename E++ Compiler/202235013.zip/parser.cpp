/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "parser.h"

//Write your code below this line
using namespace std;
Parser::Parser(){
    symtable=new SymbolTable();
    last_deleted=-1;
}
bool check(string s){
    if (s=="-") return false;
    else if (s[0]=='-' || isdigit(s[0])){
        for(int i=1;i<int(s.size());i++){
            if (not isdigit(s[i])) return false;
        }
        return true;
    }
    else return false;
}
void Parser::parse(vector<string> expression){
    ExprTreeNode* root=new ExprTreeNode(":=",0);
    if (expression[0]==("del")){
        root->left=new ExprTreeNode("DEL",0);
        root->right=new ExprTreeNode("VAR",0);
        root->right->id=expression[2];
        expr_trees.push_back(root);
        last_deleted=symtable->search(expression[2]);
        symtable->remove(expression[2]);
        return;
    }
    if (expression[0]==("ret")) root->left=new ExprTreeNode("RET",0);
    else {root->left=new ExprTreeNode("VAR",0);
    root->left->id=expression[0];
    if (symtable->search(expression[0])==-2){
        symtable->insert(expression[0]);
    }}
    expr_trees.push_back(root);
    
    vector<ExprTreeNode*>number{},op{};
    for(int i=2;i<(int)expression.size();i++){
        if (expression[i]=="("){
            number.push_back(new ExprTreeNode());
        }else if (expression[i]==")"){
            if (op.empty()){
                auto it=number.begin()+number.size()-2;
                delete *it;
                number.erase(it);
            }else{
                ExprTreeNode* t_right=*(number.rbegin());
                number.pop_back();
                ExprTreeNode* t_left=*(number.rbegin());
                number.pop_back();
                ExprTreeNode* lb=*(number.rbegin());
                number.pop_back();
                delete lb;
                ExprTreeNode* opp=*(op.rbegin());
                op.pop_back();
                opp->left=t_left;
                opp->right=t_right;
                if (opp->type=="ADD")opp->num=opp->left->num+opp->right->num;
                else if (opp->type=="SUB")opp->num=opp->left->num-opp->right->num;
                else if (opp->type=="MUL")opp->num=(opp->left->num)*(opp->right->num);
                else if (opp->type=="DIV"){
                    int a{opp->num=opp->left->num},b{opp->right->num};
                    if (b!=0){
                        opp->num=a/b;
                        if ((a%b!=0) and (a*b)<0) opp->num--;
                    }else opp->num=-6969;
                }
                number.push_back(opp);
            }
        }else if(check(expression[i])) {number.push_back(new ExprTreeNode("VAL",stoi(expression[i])));}
        else if (expression[i]=="+") {op.push_back(new ExprTreeNode("ADD",0));}
        else if (expression[i]=="-") {op.push_back(new ExprTreeNode("SUB",0));}
        else if (expression[i]=="*") {op.push_back(new ExprTreeNode("MUL",0));}
        else if (expression[i]=="/") {op.push_back(new ExprTreeNode("DIV",0));}
        else{
            ExprTreeNode* xxx=new ExprTreeNode("VAR",0);
            xxx->id=expression[i];
            number.push_back(xxx);
        }
    }
    root->right=number[0];
    if (root->left->type=="VAR") root->left->num=root->right->num;
    number.clear();op.clear();
}

Parser::~Parser(){
    for(auto i:expr_trees){
        delete i;
        i=NULL;
    }
    expr_trees.clear();
    delete symtable;
    symtable=NULL;
}