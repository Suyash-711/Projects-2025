/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "symtable.h"
//Write your code below this line

// TO WRITE: DESTRUCTOR

int het(SymNode*& node){
    if (node) return node->height;
    else return -1;
}

void restructure_insertion(const string& k,SymNode*& root,SymNode*& z){
    if (z==NULL) return;
    SymNode *y{NULL},*x{NULL};
    int what{1};
    if (k<(z->key)) y=z->left;
    else{
        y=z->right;
        what+=2;
    }
    if (k<(y->key)) x=y->left;
    else{
        x=y->right;
        what++;
    }
    // do the rotations
    if (what==1){
        z->RightRightRotation();
        if (root==z) root=y;
    }
    else if (what==2){
        z->LeftRightRotation();
        if (root==z) root=x;
    }
    else if (what==3){
        z->RightLeftRotation();
        if (root==z) root=x;
    }
    else{
        z->LeftLeftRotation();
        if (root==z) root=y;
    }
}

void restructure_deletion(const string& k,SymNode*& root,SymNode*& z){
    SymNode *y{NULL}, *x{NULL};
    int what{1};
    if (het(z->left)>het(z->right)) y=z->left;
    else{
        what+=2;
        y=z->right;
    }
    if (het(y->left)>het(y->right)) x=y->left;
    else if (het(y->left)==het(y->right));
    else{
        what++;
        x=y->right;
    }
    // do the rotations
    if (x==NULL){
        if (what==1) z->RightRightRotation();
        else z->LeftLeftRotation();
        if (root==z) root=y;
    }
    else{if (what==1){
        z->RightRightRotation();
        if (root==z) root=y;
    }
    else if (what==2){
        z->LeftRightRotation();
        if (root==z) root=x;
    }
    else if (what==3){
        z->RightLeftRotation();
        if (root==z) root=x;
    }
    else{
        z->LeftLeftRotation();
        if (root==z) root=y;
    }}   
}

SymNode* find(const string k,SymNode* root){
    SymNode* current=root;
    while(current){
        if (k==current->key) break;
        else if (k<current->key) current=current->left;
        else current=current->right;
    }
    return current;
}

SymbolTable::SymbolTable(){
    root=NULL;
    size=0;
}

void SymbolTable::insert(string k){
    SymNode* newnode=new SymNode(k);
    size++;
    if (size==1){
        root=newnode;
        return;
    }
    // regular insertion  
    SymNode* current=root;
    SymNode* parent=NULL;
    while(current){
        parent=current;
        if (k<(current->key)) current=current->left;
        else current=current->right;
    }
    newnode->par=parent;
    if (parent){
        if (k<(parent->key)) parent->left=newnode;
        else parent->right=newnode;
    }

    // updating the heights
    SymNode* z=NULL;
    current=newnode;
    int diff{0};

    do{
        current=current->par;
        diff=het(current->right)-het(current->left);
        if (diff>1 || diff<-1){
            z=current;
            break;
        }
        int temp{current->height};
        current->height=1+max(het(current->left),het(current->right));
        if (temp==current->height) break;
    }while(current->par);

    // rebalance
    restructure_insertion(k,root,z);
    
}

void nonodedel(SymNode*& root,SymNode*& current){
    if (current==root) root=NULL;
    else{
        if (current->par->left==current) current->par->left=NULL;
        else current->par->right=NULL;
    }
    current->left=NULL;current->right=NULL;
    delete current;
    current=NULL;
}

void onlyleftdel(SymNode*& root, SymNode*& current){
    if (current==root){
        root=root->left; 
        root->par=NULL;
    }else{
        if (current->par->left==current) current->par->left=current->left;
        else current->par->right=current->left;
        current->left->par=current->par;
    }
    current->left=NULL;current->right=NULL;
    delete current;
    current=NULL;
}

void onlyrightdel(SymNode*& root, SymNode*& current){
    if (current==root){
        root=root->right;
        root->par=NULL;
    }else{
        if (current->par->left==current) current->par->left=current->right;
        else current->par->right=current->right;
        current->right->par=current->par; 
    }
    current->left=NULL;current->right=NULL;
    delete current;
    current=NULL;
}

void SymbolTable::remove(string k){
    // finding the element
    SymNode* current=find(k,root);
    if (current==NULL) return; // not found
    size--;
    SymNode* it=NULL;
    // deleting normally
    if (current->left==NULL and current->right==NULL){    // leaf node deletion
        it=current->par;
        nonodedel(root,current);
    }
    else if (current->left!=NULL and current->right==NULL){      // node with one child deletion
        it=current->par;
        onlyleftdel(root,current);
    }
    else if (current->left==NULL and current->right!=NULL){      // node with one child deletion
        it=current->par;
        onlyrightdel(root,current);
    }
    else{      // node with two child deletion
        
        // first find the successor
        SymNode* suck=current->right;
        while (suck->left) suck=suck->left;
        it=suck->par;
        //copy the contents of the sucksessor into the current node;
        current->address=suck->address;
        current->key=suck->key;

        //now delete the suck
        if (suck->right==NULL){    // leaf node deletion
            nonodedel(root,suck);
        }
        else{      // node with one child deletion
            onlyrightdel(root,suck);
        }
    }
    // now restructure_deletion the tree
    while(it){
        SymNode* z=NULL;
        current=it;
        int diff{0};

        while(current){
            diff=het(current->right)-het(current->left);
            if (diff>1 || diff<-1){
                z=current;
                break;
            }
            int temp{current->height};
            current->height=1+max(het(current->left),het(current->right));
            if (temp==current->height) break;
            current=current->par;
        }
        if (z==NULL) break;
        // rebalance
        it=z->par;
        restructure_deletion(k,root,z);
    }
}

int SymbolTable::search(string k){
    SymNode* ax=find(k,root);
    if (ax) return ax->address;
    else return -2;
}

void SymbolTable::assign_address(string k,int idx){
    find(k,root)->address=idx;
}

int SymbolTable::get_size(){
    return size;
}

SymNode* SymbolTable::get_root(){
    return root;
}

SymbolTable::~SymbolTable(){
    delete root;
    size=0;
}
