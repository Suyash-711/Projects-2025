/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "eppcompiler.h"

//Write your code below this line

EPPCompiler::EPPCompiler(){
    targ;   // parser
    memory_size=0;
    output_file="xxx.txt";
    least_mem_loc;
}

EPPCompiler::EPPCompiler(string out_file,int mem_limit){
    targ;   // parser
    memory_size=mem_limit;
    output_file=out_file;
    for(int i=0;i<memory_size;i++) least_mem_loc.push_heap(i);
}

void postorder(ExprTreeNode*& root,vector<string>& s,SymbolTable*& symtable){
    if (root==NULL) return;
    if ((root->num)==-6969) return;
    if (root->left) if ((root->left->num)==-6969) return;
    if (root->right) if ((root->right->num)==-6969) return;
    
    if (root->type=="VAL"){
        s.push_back("PUSH "+to_string(root->num));
    }else if(root->type=="VAR"){
        s.push_back("PUSH mem["+to_string(symtable->search(root->id))+"]");
    }else if(root->type=="ADD"){
        postorder(root->right,s,symtable);
        postorder(root->left,s,symtable);
        s.push_back("ADD");
    }else if(root->type=="SUB"){
        postorder(root->right,s,symtable);
        postorder(root->left,s,symtable);
        s.push_back("SUB");
    }else if(root->type=="MUL"){
        postorder(root->right,s,symtable);
        postorder(root->left,s,symtable);
        s.push_back("MUL");
    }else if(root->type=="DIV"){
        if (root->right->num==0){
            root->num=-6969;return;
        }
        postorder(root->right,s,symtable);
        postorder(root->left,s,symtable);
        s.push_back("DIV");
    }else if(root->type=="MOD"){
        postorder(root->right,s,symtable);
        postorder(root->left,s,symtable);
        s.push_back("MOD");
    }
}

void EPPCompiler::compile(vector<vector<string>> code){
    fstream file(output_file,ios::out|ios::trunc);
    file.close();
    for(auto expression:code){
        targ.parse(expression);
        if (expression[0]==("ret"));
        else if (expression[0]==("del")){
            least_mem_loc.push_heap(targ.last_deleted);
        }else{
            if (targ.symtable->search(expression[0])==-1){
                int add{least_mem_loc.get_min()};
                least_mem_loc.pop();
                targ.symtable->assign_address(expression[0],add);
            }
        }
        write_to_file(generate_targ_commands());
    }
}

vector<string> EPPCompiler::generate_targ_commands(){
    ExprTreeNode* root=targ.expr_trees[targ.expr_trees.size()-1];
    vector<string> s{};
    string str{};
    if (root->left->type=="DEL"){
        str="DEL = mem["+to_string(targ.last_deleted)+"]";
    }else if(root->left->type=="RET"){
        postorder(root->right,s,targ.symtable);
        str="RET = POP";
    }else {  // if (root->left->type=="VAR"){
        str="mem["+to_string(targ.symtable->search(root->left->id))+"] = POP";
        postorder(root->right,s,targ.symtable);
    }
    s.push_back(str);
    return s;
}

void EPPCompiler::write_to_file(vector<string> commands){
    fstream file(output_file,ios::out|ios::app);
    for(string line:commands){
        file<<line<<endl;
    }
    file.close();
}

EPPCompiler::~EPPCompiler(){
    // memory_size=0;
    // output_file="";
    // delete targ.symtable;
    // targ.symtable=NULL;
    // delete targ.expr_trees;
    // for(auto i:targ.expr_trees){
    //     delete i;
    //     i=NULL;
    // }
}