/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "exprtreenode.h"
// #include <iostream>
ExprTreeNode::ExprTreeNode(){
    type="VAL";
    val=new UnlimitedRational();
    evaluated_value=new UnlimitedRational();
    id="";
    left=nullptr;
    right=nullptr;
}
ExprTreeNode::ExprTreeNode(string t,UnlimitedInt* v){
    type=t;
    val=new UnlimitedRational();
    UnlimitedInt* one=new UnlimitedInt(1);
    evaluated_value=new UnlimitedRational(v,one);
    id="";
    left=nullptr;
    right=nullptr;
}
ExprTreeNode::ExprTreeNode(string t,UnlimitedRational* v){
    type=t;
    val=new UnlimitedRational();
    evaluated_value=v;
    id="";
    left=nullptr;
    right=nullptr;
}
ExprTreeNode::~ExprTreeNode(){
    type="";
    delete val;
    val=nullptr; 
    delete evaluated_value;
    evaluated_value=nullptr;
    id="";
    delete left;
    left=nullptr;
    delete right;
    right=nullptr;
}
// nodes of the parse tree, which shall be made for each statement