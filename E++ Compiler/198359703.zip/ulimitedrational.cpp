/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "ulimitedrational.h"
// #include <iostream>
//comparing the absolute values of the two objects
int comparator(UnlimitedInt* i1,UnlimitedInt* i2){
    int s1{i1->get_size()}, s2{i2->get_size()};int *arr{i1->get_array()},*brr{i2->get_array()};
    int comp;
    if (s1<s2) comp=-1;
    else if (s1>s2) comp=1;
    else{
        comp=0;
        for(int i=s1-1; i>=0; i--){
            if (arr[i]>brr[i]){
                comp=1;
                break;
            }else if(arr[i]<brr[i]){
                comp=-1;
                break;
            }
        }
    }
    return comp;
}
UnlimitedInt* hcf(UnlimitedInt* i1, UnlimitedInt* i2){
    if (i1->get_sign()==0){
        UnlimitedInt* tempo=new UnlimitedInt(i2->get_array(),i2->get_capacity(),1,i2->get_size());
        return tempo;
    }
    if (i2->get_sign()==0){
        UnlimitedInt* tempo=new UnlimitedInt(i2->get_array(),i2->get_capacity(),1,i2->get_size());
        return tempo;
    }
    int c{comparator(i1,i2)};
    if (c==0){
        UnlimitedInt* x=new UnlimitedInt(i2->get_array(),i2->get_capacity(),1,i2->get_size());
        return x;
    }else if (c==1){
        return hcf(UnlimitedInt::mod(i1,i2),i2);
    }else{
        return hcf(UnlimitedInt::mod(i2,i1),i1);
    }
}

UnlimitedRational::UnlimitedRational(){
    p=new UnlimitedInt();
    q=new UnlimitedInt(1);
}
UnlimitedRational::UnlimitedRational(UnlimitedInt* num, UnlimitedInt* den){
    UnlimitedInt* factor=hcf(num,den);
    if (num->get_sign()==0 and den->get_sign()!=0){
        p=new UnlimitedInt();
        q=new UnlimitedInt(1);
    }else if (den->get_sign()==0){
        p=new UnlimitedInt();
        q=new UnlimitedInt();
    }else{
        p=UnlimitedInt::div(num,factor);
        q=UnlimitedInt::div(den,factor);
    }
}
UnlimitedRational::~UnlimitedRational(){
    delete p;
    delete q;
}
UnlimitedInt* UnlimitedRational::get_p(){
    return p;
}
UnlimitedInt* UnlimitedRational::get_q(){
    return q;
}
string UnlimitedRational::get_p_str(){
    return p->UnlimitedInt::to_string();
}
string UnlimitedRational::get_q_str(){
    return q->UnlimitedInt::to_string();
}
string UnlimitedRational::get_frac_str(){
    return (this->p->UnlimitedInt::to_string())+ "/"+ (this->q->UnlimitedInt::to_string());
}
UnlimitedRational* UnlimitedRational::add(UnlimitedRational* i1, UnlimitedRational* i2){
    if (((i1->p->get_sign()==0) and (i1->q->get_sign()==0)) or ((i2->p->get_sign()==0) and (i2->q->get_sign()==0))){
    }
    UnlimitedInt* n=UnlimitedInt::add(UnlimitedInt::mul(i1->p,i2->q),UnlimitedInt::mul(i1->q,i2->p));
    UnlimitedInt* d=UnlimitedInt::mul(i1->q,i2->q);
    UnlimitedRational* term=new UnlimitedRational(n,d);
    return term;
}
UnlimitedRational* UnlimitedRational::sub(UnlimitedRational* i1, UnlimitedRational* i2){
    if (((i1->p->get_sign()==0) and (i1->q->get_sign()==0)) or ((i2->p->get_sign()==0) and (i2->q->get_sign()==0))){
    }
    UnlimitedInt* n=UnlimitedInt::sub(UnlimitedInt::mul(i1->p,i2->q),UnlimitedInt::mul(i1->q,i2->p));
    UnlimitedInt* d=UnlimitedInt::mul(i1->q,i2->q);
    UnlimitedRational* term=new UnlimitedRational(n,d);
    return term;
}
UnlimitedRational* UnlimitedRational::mul(UnlimitedRational* i1, UnlimitedRational* i2){
    if (((i1->p->get_sign()==0) and (i1->q->get_sign()==0)) or ((i2->p->get_sign()==0) and (i2->q->get_sign()==0))){
    }
    UnlimitedInt* n=UnlimitedInt::mul(i1->p,i2->p);
    UnlimitedInt* d=UnlimitedInt::mul(i1->q,i2->q);
    UnlimitedRational* term=new UnlimitedRational(n,d);
    return term;
}
UnlimitedRational* UnlimitedRational::div(UnlimitedRational* i1, UnlimitedRational* i2){
    if (((i1->p->get_sign()==0) and (i1->q->get_sign()==0)) or ((i2->p->get_sign()==0) and (i2->q->get_sign()==0))){
    }
    UnlimitedInt* n=UnlimitedInt::mul(i1->p,i2->q);
    UnlimitedInt* d=UnlimitedInt::mul(i1->q,i2->p);
    UnlimitedRational* term=new UnlimitedRational(n,d);
    return term;
}
// int main(){
//     string x,y,z,w;
//     UnlimitedInt* a,* b,*c,*d;
//     UnlimitedRational *t,*r,*s;
//     // for(int i=0;i<10;i++){
//     cin>>x>>y>>z>>w;
//     a=new UnlimitedInt(x);
//     b=new UnlimitedInt(y);
//     c=new UnlimitedInt(z);
//     d=new UnlimitedInt(w);
//     r=new UnlimitedRational(a,b);
//     s=new UnlimitedRational(c,d);
//     t=UnlimitedRational::add(s,r);
//     // cout<<b->to_string();
//     cout<<t->UnlimitedRational::get_frac_str()<<endl;
//     // }
//     return 0;
// }