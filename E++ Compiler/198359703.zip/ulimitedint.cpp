/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "ulimitedint.h"
#include <iostream>
int compare(UnlimitedInt* i1,UnlimitedInt* i2){
    int s1{i1->get_size()}, s2{i2->get_size()};int *arr{i1->get_array()},*brr{i2->get_array()};
    //comparing the abs value of two numbers;
    //1 if |a|>|b|; 0 if |a|==|b|; -1 if |a|<|b|;
    int comp;
    if (s1<s2) comp=-1;
    else if (s1>s2) comp=1;
    else{
        comp=0;
        for(int i=s1-1; i>=0; i--){
            if (arr[i]>brr[i]){
                comp=1;
                break;
            }else if(arr[i]<brr[i]){
                comp=-1;
                break;
            }
        }
    }
    return comp;
}

UnlimitedInt::UnlimitedInt(){
    size=1;
    sign=0;
    capacity=1;
    unlimited_int=new int;
    *unlimited_int=0;
}
UnlimitedInt::UnlimitedInt(string s){
    if (s[0]=='0'){
        size=1;
        sign=0;
        capacity=1;
        unlimited_int=new int[size];
        unlimited_int[0]=0;
    }else if (s[0]=='-'){
        size=s.size()-1;
        sign=-1;
        capacity=size;
        unlimited_int=new int[size];
        for(int i=0;i<size;i++)unlimited_int[i]=s[size-i]-'0';
    }else{
        size=s.size();
        sign=1;
        capacity=size;
        unlimited_int=new int[size];
        for(int i=0;i<size;i++)unlimited_int[i]=s[size-1-i]-'0';
    }
}

UnlimitedInt::UnlimitedInt(int i){
    if (i==0){
        size=1;
        sign=0;
        capacity=1;
        unlimited_int=new int[0];
        unlimited_int[0]=0;
    }else{
        if (i>0) sign=1;
        else{
            sign=-1;
            i=-i;
        }
        int j{i};
        size=0;
        while(j>0){
            j/=10;
            size++;
        }
        j=0;
        unlimited_int=new int[size];
        while(i>0){
            unlimited_int[j]=i%10;
            i/=10;
            j++;
        }
        capacity=size;
    }
}

UnlimitedInt::UnlimitedInt(int* ulimited_int, int cap, int sgn, int sz){
    unlimited_int=ulimited_int;
    capacity=cap;
    sign=sgn;
    size=sz;
}

UnlimitedInt::~UnlimitedInt(){
    delete[] unlimited_int;
    size=0;
    capacity=0;
    sign=0;
}

int UnlimitedInt::get_size(){
    return size;
}

int* UnlimitedInt::get_array(){
    return unlimited_int;
}

int UnlimitedInt::get_sign(){
    return sign;
}

int UnlimitedInt::get_capacity(){
    return capacity;
}

UnlimitedInt* UnlimitedInt:: add(UnlimitedInt* i1, UnlimitedInt* i2){
    UnlimitedInt* sum= new UnlimitedInt;
    if ((i1->sign)==0 && (i2->sign)==0){
        return sum;
    }else if ((i1->sign)==0 && (i2->sign)!=0){
        sum=new UnlimitedInt(i2->unlimited_int,i2->capacity,i2->sign,i2->size);
        return sum;
    }else if ((i1->sign)!=0 && (i2->sign)==0){
        sum=new UnlimitedInt(i1->unlimited_int,i1->capacity,i1->sign,i1->size);
        return sum;
    }
    else if ((i1->sign)*(i2->sign)>0){
        int sn=1;//this sign
        if (i1->sign==-1) sn=-1; 
        int carry{0},ind{0};
        int s1{i1->get_size()}, s2{i2->get_size()};
        int *arr{i1->get_array()},*brr{i2->get_array()};
        int* s=new int[max(s1,s2)+1]{};
        int temp;
        while(ind<s1 && ind<s2){
            temp=arr[ind]+brr[ind]+carry;
            s[ind]=temp%10;
            carry=temp/10;
            ind++;
        }
        while(ind<s1){
            temp=arr[ind]+carry;
            s[ind]=temp%10;
            carry=temp/10;
            ind++;
        }
        while(ind<s2){
            temp=brr[ind]+carry;
            s[ind]=temp%10;
            carry=temp/10;
            ind++;
        }
        if (carry==1){
            s[ind]=1;
            ind++;
        }
        sum->sign=sn;
        sum->size=ind;
        sum->unlimited_int=s;
        sum->capacity=(max(s1,s2)+1);
        return sum;
    }else{
        int s1{i1->get_size()}, s2{i2->get_size()};int *arr{i1->get_array()},*brr{i2->get_array()};
        //comparing the abs value of two numbers;
        int comp=compare(i1,i2);
        int sg;
        if (comp==0){
            return sum;
        }
        else{
            UnlimitedInt *xx,*yy;
            if (comp==1){
                xx=i1;
                yy=i2;
            }else{
                xx=i2;
                yy=i1;
            }//now we have to do a-b; it will give the correct magnitude;
            arr=xx->get_array();brr=yy->get_array();
            sg=comp*(i1->sign);
            int carry{0},ind{0};
            int* s=new int[max(s1,s2)]{};
            int temp;

            while(ind<s1 && ind<s2){
                temp=arr[ind]-brr[ind]+carry;
                s[ind]=(10+temp)%10;
                carry=-(temp<0);
                ind++;
            }
            while(ind<s1){
                temp=arr[ind]+carry;
                s[ind]=(10+temp)%10;
                carry=-(temp<0);
                ind++;
            }
            while(ind<s2){
                temp=brr[ind]+carry;
                s[ind]=(10+temp)%10;
                carry=-(temp<0);
                ind++;
            }
            int it{0},ans{};
            while(it<ind){
                if (s[it]!=0)ans=it;
                it++;
            }
            sum->sign=sg;
            sum->size=ans+1;
            sum->unlimited_int=s;
            sum->capacity=(max(s1,s2));
            return sum;
        }
    }
}

UnlimitedInt* UnlimitedInt:: sub(UnlimitedInt* i1, UnlimitedInt* i2){
    UnlimitedInt* x;
    x=(i2);
    x->sign=-x->sign;
    UnlimitedInt* temp=add(i1,x);
    i2->sign=-i2->sign;
    return temp;
}

UnlimitedInt* UnlimitedInt:: mul(UnlimitedInt* i1, UnlimitedInt* i2){
    int s1{i1->get_size()}, s2{i2->get_size()};
    int *arr{i1->get_array()},*brr{i2->get_array()};
    UnlimitedInt* mult;
    if (i1->sign*i2->sign==0){
        mult=new UnlimitedInt;
        return mult;
    }
    int sg{(i1->sign)*(i2->sign)};
    int* current=new int[s1+s2]{};// if we consider current to be a local variable then the function fails after one operation
    for(int i=0; i<s2; i++){
        const int& m=brr[i];
        for(int j=0; j<s1; j++){
            current[i+j]+=m*arr[j];
        }
    }
    int carry{0},sz{0};
    for(int i=0;i<s1+s2;i++){
        int temp{carry+current[i]};
        current[i]=temp%10;
        if (current[i]!=0) sz=i;
        carry=temp/10;
    }
    mult=new UnlimitedInt(current,s1+s2,sg,sz+1);
    return mult;
}
UnlimitedInt* UnlimitedInt::div(UnlimitedInt* i1,UnlimitedInt* i2){
    UnlimitedInt* divi;
    // i1/i2
    if (i1->get_sign()==0){
        divi=new UnlimitedInt();
        return divi;
    }
    int s1{i1->get_size()};
    int* arr{i1->get_array()};
    int* result=new int[s1]{};
    UnlimitedInt** multiplicator=new UnlimitedInt*[10];
    UnlimitedInt* ten=new UnlimitedInt(10);
    int sss=i2->sign;
    i2->sign=1;
    for(int i=0; i<10; i++){
        UnlimitedInt* x=new UnlimitedInt(i);
        multiplicator[i]=UnlimitedInt::mul(i2,x);
    }
    i2->sign=sss;
    int it{0};
    UnlimitedInt* temp=new UnlimitedInt;
    bool good{false};
    for(int z=s1-1;z>=0;z--){
        UnlimitedInt* nowdigit=new UnlimitedInt(arr[z]);
        temp=add(mul(temp,ten),nowdigit);
        if (compare(temp,i2)==-1){
            result[it++]=0;
            continue;
        }
        int i{0};
        while(i<10){
            if (compare(multiplicator[i],temp)==1) break;
            i++;
        }i--;
        result[it++]=i;
        temp=sub(temp,multiplicator[i]);
        good=temp->get_sign()==0;
    }
    int* tempp=new int[it];
    int szz{0};
    for(int k=it;k>=0;k--)tempp[it-1-k]=result[k];
    for(int i=0;i<it;i++){
        if (tempp[i]!=0) szz=i;
    }
    if (i1->get_sign()*i2->get_sign()>0)divi=new UnlimitedInt(tempp,it,1,szz+1);
    else{
        divi=new UnlimitedInt(tempp,it,-1,szz+1);
        if (not good){
            UnlimitedInt* mone=new UnlimitedInt(-1);
            divi=add(divi,mone);
        }
    }
    return divi;
}

UnlimitedInt* UnlimitedInt::mod(UnlimitedInt* i1,UnlimitedInt* i2){ // check what to return in the cases +/+ +/- -/+ -/- respectivelyy
    UnlimitedInt* modu;
    //consideration:i1 mod i2
    //not considering the zero division case
    UnlimitedInt* flor=UnlimitedInt::div(i1,i2);
    modu=sub(i1,mul(flor,i2));
    return modu;
}
string UnlimitedInt::to_string(){
    string s="";
    if (this->get_sign()==0) return "0";
    if (this->get_sign()<0) s+="-";
    for(int i=this->size-1;i>=0;i--){
        s+=std::to_string(this->get_array()[i]);
    }
    return s;
}
// int main(){
//     for(int i=0; i<10; i++){
//         string x,y;cin>>x>>y;
//         UnlimitedInt* a=new UnlimitedInt(x);
//         UnlimitedInt* b=new UnlimitedInt(y);
//         cout<<UnlimitedInt::div(a,b)->to_string()<<endl;
//     }
//     return 0;
// }