/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "entry.h"
// #include <iostream>
SymEntry::SymEntry(){
    key="";
    val=new UnlimitedRational();
    left=nullptr;
    right=nullptr;
}
SymEntry::SymEntry(string k,UnlimitedRational* v){
    key=k;
    val=v;
    left=nullptr;
    right=nullptr;
}
SymEntry::~SymEntry(){
    key="";
    delete val;
    delete this->left;
    delete this->right;
    left=nullptr;
    right=nullptr;
}
// stores the nodes of the symtable
// check the destructor function