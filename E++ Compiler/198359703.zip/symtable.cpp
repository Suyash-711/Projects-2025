/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "symtable.h"
// #include <iostream>
SymbolTable::SymbolTable(){
    size=0;
    root=nullptr;
}

SymbolTable::~SymbolTable(){
    delete root;
    root=nullptr;
    size=0;
}

void SymbolTable::insert(string k,UnlimitedRational* v){
    SymEntry* current=this->root;
    SymEntry* parent=nullptr;
    SymEntry* newnode=new SymEntry(k,v);
    while(current!=nullptr){
        parent=current;
        if (k<current->key) current=current->left;
        else current=current->right;
    }
    if (root==nullptr) root=newnode;
    else if (k<parent->key) parent->left=newnode;
    else parent->right=newnode;
    size++;
}

void SymbolTable::remove(string k){
    SymEntry* current=this->root;
    SymEntry* parent=nullptr;
    // finding the place to insert
    while(current->key!=k and current){
        parent=current;
        if (k<current->key) current=current->left;
        else current=current->right;
    }
    // not found
    if (current==nullptr) return;
    // leaf node
    if (current->left==nullptr and current->right==nullptr){
        if (parent){
            if (current==parent->left) parent->left=nullptr;
            else parent->right=nullptr;
        }
    // only one child
    }else if (current->right==nullptr){
        if (parent){
            if (current==parent->left) parent->left=nullptr;
            else parent->right=nullptr;
        }
    // only one child
    }else if (current->left==nullptr){
        if (parent){
            if (current==parent->left) parent->left=nullptr;
            else parent->right=nullptr;
        }
    // both child
    }else{
        // finding the successor(suck-sessor)
        SymEntry* suck=current->right;
        SymEntry* suckparent=current;
        // start
        while(suck->left){
            suckparent=suck;
            suck=suck->left;
        }
        // found
        // switch the value of the current with the suck
        current->key=suck->key;
        current->val=suck->val;
        // delete the suck
        if (suck==suckparent->left) suckparent->left=suck->right;
        else suckparent->right=suck->right;
    }
    size--;
}
UnlimitedRational* SymbolTable::search(string k){ // what if not found
    SymEntry* current=root;
    while(current->key!=k and current){
        if (k<current->key) current=current->left;
        else current=current->right;
    }
    if (current==nullptr){
        return new UnlimitedRational();
    }else return current->val;
}
int SymbolTable::get_size(){
    return this->size;
}
SymEntry* SymbolTable::get_root(){
    return this->root;
}
// stores the values of the calculated values of the statements in form of a bst tree
// having the nodes of the entry.cpp

// int main(){
//     SymbolTable* tree=new SymbolTable;
//     UnlimitedInt* one=new UnlimitedInt(1);
//     string x;int n;
//     UnlimitedInt* num;UnlimitedRational* rat;
//     int count;cin>>count;
//     for(int i=0; i<count; i++){
//         cout<<"key:";cin>>x;
//         // cout<<"number:";cin>>n;
//         num=new UnlimitedInt(i);
//         rat=new UnlimitedRational(num,one);
//         tree->insert(x,rat);
//         cout<<"PREORDER:";
//         preorder(tree->get_root());
//         cout<<"INORDER:";
//         inorder(tree->get_root());
//         cout<<endl;
//     }
//     cout<<"find what:";cin>>x;
//     cout<<tree->search(x)->get_frac_str();
//     // cout<<tree->get_root()->key<<endl;
//     cout<<"PREORDER:";
//     preorder(tree->get_root());
//     cout<<"INORDER:";
//     inorder(tree->get_root());
//     cout<<endl;
    
//     return 0;
// }