/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "evaluator.h"
// #include <iostream>

// void inorder(ExprTreeNode* root){
//     if (root==nullptr) return;
//     inorder(root->left);
//     if (root->type=="VAL")cout<<root->val->get_frac_str()<<" ";
//     else if (root->type=="VAR") cout<<root->id<<" ";
//     else cout<<root->type<<" ";
//     inorder(root->right);
// }
Evaluator::Evaluator(){
    vector<ExprTreeNode*> khali{};
    expr_trees=khali;
    symtable=new SymbolTable();
}

Evaluator::~Evaluator(){
    expr_trees.clear();
    delete symtable;
    symtable=nullptr;
}

void Evaluator::parse(vector<string>code){
    UnlimitedInt* zero=new UnlimitedInt;
    ExprTreeNode* root=new ExprTreeNode();
    root->type=":=";
    expr_trees.push_back(root);
    root->left=new ExprTreeNode("VAR",zero);
    root->left->id=code[0];
    // sasta stack
    vector<ExprTreeNode*>op{};
    vector<ExprTreeNode*>num{};
    for(int i=2;i<int(code.size());i++){
        // cout<<code[i]<<endl;
        if (code[i]=="(");
        else if (code[i]=="+" || code[i]=="-" || code[i]=="*" || code[i]=="/" || code[i]=="%"){
            ExprTreeNode* ps=new ExprTreeNode();
            if (code[i]=="+") ps->type="ADD";
            else if (code[i]=="-") ps->type="SUB";
            else if (code[i]=="*") ps->type="MUL";
            else if (code[i]=="/") ps->type="DIV";
            else ps->type="MOD";
            op.push_back(ps);
        }else if (isdigit(code[i][0])){
            UnlimitedInt* xx=new UnlimitedInt(code[i]);
            ExprTreeNode* ps=new ExprTreeNode("VAL",xx);
            ps->val=ps->evaluated_value;
            num.push_back(ps);
        }else if (code[i]==")"){
            if (op.empty()) continue;
            ExprTreeNode* t_right=*(num.rbegin());
            num.pop_back();
            ExprTreeNode* t_left=*(num.rbegin());
            num.pop_back();
            ExprTreeNode* opp=*(op.rbegin());
            op.pop_back();
            opp->left=t_left;
            opp->right=t_right;
            num.push_back(opp);
        }else{
            ExprTreeNode* ps=new ExprTreeNode();
            ps->type="VAR";
            ps->id=code[i];
            ps->evaluated_value=symtable->search(code[i]);
            num.push_back(ps);
        }
    }
    root->right=num[0];
    num.clear();op.clear();
}
UnlimitedRational* evaluate(ExprTreeNode* root){
    if (root->type=="ADD"){
        UnlimitedRational* temp=UnlimitedRational::add(evaluate(root->left),evaluate(root->right));
        root->evaluated_value=temp;
        return temp;
    }else if(root->type=="SUB"){
        UnlimitedRational* temp=UnlimitedRational::sub(evaluate(root->left),evaluate(root->right));
        root->evaluated_value=temp;
        return temp;
    }else if(root->type=="DIV"){
        UnlimitedRational* temp=UnlimitedRational::div(evaluate(root->left),evaluate(root->right));
        root->evaluated_value=temp;
        return temp;
    }else if (root->type=="MUL"){
        UnlimitedRational* temp=UnlimitedRational::mul(evaluate(root->left),evaluate(root->right));
        root->evaluated_value=temp;
        return temp;
    }else if (root->type=="MOD"){
        UnlimitedRational* a=evaluate(root->left);
        UnlimitedRational* b=evaluate(root->right);
        UnlimitedInt* ans=UnlimitedInt::mod(a->get_p(),b->get_p());
        UnlimitedInt* one=new UnlimitedInt(1);
        UnlimitedRational* report=new UnlimitedRational(ans,one);
        root->evaluated_value=report;
        return report;
    }
    else{
        return root->evaluated_value;
    }
}
void Evaluator::eval(){
    UnlimitedRational* value=new UnlimitedRational();
    ExprTreeNode* root=*(expr_trees.rbegin());
    value=evaluate(root->right);
    root->left->evaluated_value=value;
    symtable->insert(root->left->id,value);
}
// int main(){
//     // v:=(13+(2/51))
//     // g:=(2*v)
//     // x:=(g+6)
//     // y:=x
//     vector<string> token={"v", ":=", "(", "13", "+", "(", "2", "/", "51", ")", ")"};
//     // vector<string> token={"v", ":=","(","5","+","3",")"};
//     Evaluator* sth=new Evaluator();
//     sth->parse(token);
//     sth->eval();
//     vector<string> choken={"g", ":=","(","2","*","v",")"};
//     sth->parse(choken);
//     sth->eval();
//     vector<string> thoken={"x", ":=","(","g","+","6",")"};
//     sth->parse(thoken);
//     sth->eval();
//     vector<string> uhoken={"y", ":=","x"};
//     sth->parse(uhoken);
//     sth->eval();
//     for(auto something:sth->expr_trees){
//         inorder(something);
//         cout<<endl;
//         cout<<something->left->evaluated_value->get_frac_str();
//         cout<<endl;

//     }
//     return 0;
// }