#include "kdtree.h"
#include <algorithm>
#include <cmath>
#include <queue>

KDTree::KDTree(const std::vector<Point>& points, int dims) : dims(dims) {
    root = build(points, 0);
}

std::unique_ptr<KDNode> KDTree::build(std::vector<Point> points, int depth) {
    if (points.empty()) return nullptr;
    int axis = depth % dims;
    std::nth_element(points.begin(), points.begin() + points.size()/2, points.end(),
                     [axis](const Point& a, const Point& b) {
                         return a.coords[axis] < b.coords[axis];
                     });
    int median = points.size()/2;
    auto node = std::make_unique<KDNode>();
    node->point = points[median];
    node->axis = axis;
    std::vector<Point> leftPoints(points.begin(), points.begin() + median);
    std::vector<Point> rightPoints(points.begin() + median + 1, points.end());
    node->left = build(leftPoints, depth + 1);
    node->right = build(rightPoints, depth + 1);
    return node;
}

double KDTree::distance(const Point& a, const Point& b) {
    double dist = 0;
    for (int i = 0; i < dims; i++) {
        double diff = a.coords[i] - b.coords[i];
        dist += diff * diff;
    }
    return std::sqrt(dist);
}

// kNN Search
std::vector<Point> KDTree::kNearest(const Point& target, int k) {
    std::vector<std::pair<double, Point>> heap;
    kNearestRec(root.get(), target, k, heap);
    std::vector<Point> result;
    for (auto& p : heap) result.push_back(p.second);
    return result;
}

void KDTree::kNearestRec(KDNode* node, const Point& target, int k,
                         std::vector<std::pair<double, Point>>& heap) {
    if (!node) return;
    double dist = distance(target, node->point);
    if (heap.size() < k) {
        heap.push_back({dist, node->point});
        std::push_heap(heap.begin(), heap.end(), [](auto& a, auto& b){ return a.first < b.first; });
    } else if (dist < heap.front().first) {
        std::pop_heap(heap.begin(), heap.end(), [](auto& a, auto& b){ return a.first < b.first; });
        heap.pop_back();
        heap.push_back({dist, node->point});
        std::push_heap(heap.begin(), heap.end(), [](auto& a, auto& b){ return a.first < b.first; });
    }
    int axis = node->axis;
    KDNode* nearChild = target.coords[axis] < node->point.coords[axis] ? node->left.get() : node->right.get();
    KDNode* farChild = target.coords[axis] < node->point.coords[axis] ? node->right.get() : node->left.get();
    kNearestRec(nearChild, target, k, heap);
    if (heap.size() < k || std::abs(target.coords[axis] - node->point.coords[axis]) < heap.front().first) {
        kNearestRec(farChild, target, k, heap);
    }
}

// Radius Search
std::vector<Point> KDTree::radiusSearch(const Point& target, double radius) {
    std::vector<Point> result;
    radiusSearchRec(root.get(), target, radius, result);
    return result;
}

void KDTree::radiusSearchRec(KDNode* node, const Point& target, double radius,
                             std::vector<Point>& result) {
    if (!node) return;
    double dist = distance(target, node->point);
    if (dist <= radius) result.push_back(node->point);
    int axis = node->axis;
    if (target.coords[axis] - radius <= node->point.coords[axis])
        radiusSearchRec(node->left.get(), target, radius, result);
    if (target.coords[axis] + radius >= node->point.coords[axis])
        radiusSearchRec(node->right.get(), target, radius, result);
}

// Range Search
std::vector<Point> KDTree::rangeSearch(const std::vector<double>& minRange,
                                       const std::vector<double>& maxRange) {
    std::vector<Point> result;
    rangeSearchRec(root.get(), minRange, maxRange, result);
    return result;
}

void KDTree::rangeSearchRec(KDNode* node,
                            const std::vector<double>& minRange,
                            const std::vector<double>& maxRange,
                            std::vector<Point>& result) {
    if (!node) return;
    bool inside = true;
    for (int i = 0; i < dims; i++) {
        if (node->point.coords[i] < minRange[i] || node->point.coords[i] > maxRange[i]) {
            inside = false;
            break;
        }
    }
    if (inside) result.push_back(node->point);
    int axis = node->axis;
    if (minRange[axis] <= node->point.coords[axis])
        rangeSearchRec(node->left.get(), minRange, maxRange, result);
    if (maxRange[axis] >= node->point.coords[axis])
        rangeSearchRec(node->right.get(), minRange, maxRange, result);
}
