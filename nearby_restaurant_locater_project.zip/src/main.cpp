#include "kdtree.h"
#include <iostream>
#include <fstream>
#include <sstream>

std::vector<Point> loadCSV(const std::string& filename) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        // Try a common alternative path (one level up) for convenience
        std::ifstream alt("../" + filename);
        if (alt.is_open()) file.swap(alt);
        else {
            std::cerr << "ERROR: Unable to open CSV file at '" << filename << "' or '../" << filename << "'.\\n";
            return {};
        }
    }
    std::vector<Point> points;
    std::string line;
    if (!std::getline(file, line)) return points; // empty or missing header
    while (std::getline(file, line)) {
        if (line.size() == 0) continue;
        std::stringstream ss(line);
        std::string idStr, name, latStr, lonStr;
        if (!std::getline(ss, idStr, ',')) continue;
        if (!std::getline(ss, name, ',')) continue;
        if (!std::getline(ss, latStr, ',')) continue;
        if (!std::getline(ss, lonStr, ',')) continue;
        Point p;
        try {
            p.id = std::stoi(idStr);
            p.name = name;
            p.coords = {std::stod(latStr), std::stod(lonStr)};
            points.push_back(p);
        } catch (...) {
            // skip malformed lines
            continue;
        }
    }
    return points;
}

int main(int argc, char** argv) {
    std::string csv_path = \"data/restaurants.csv\";
    if (argc > 1) csv_path = argv[1];

    auto points = loadCSV(csv_path);
    if (points.empty()) {
        std::cerr << \"No points loaded. Make sure '\" << csv_path << \"' exists and is readable.\\n\";
        return 1;
    }

    KDTree tree(points, 2);
    Point query; query.coords = {28.6, 77.2}; query.id = -1; query.name = \"QueryPoint\";

    std::cout << \"Nearest 3 restaurants to (28.6, 77.2):\\n\";
    for (auto& p : tree.kNearest(query, 3)) {
        std::cout << p.id << \" - \" << p.name << \" (\" << p.coords[0] << \",\" << p.coords[1] << \")\\n\";
    }

    std::cout << \"\\nRestaurants within radius 0.2 of (28.6, 77.2):\\n\";
    for (auto& p : tree.radiusSearch(query, 0.2)) {
        std::cout << p.id << \" - \" << p.name << \"\\n\";
    }

    std::cout << \"\\nRestaurants in range [28.5,77.0] to [28.8,77.3]:\\n\";
    for (auto& p : tree.rangeSearch({28.5,77.0}, {28.8,77.3})) {
        std::cout << p.id << \" - \" << p.name << \"\\n\";
    }

    std::cout << \"\\nDone.\\n\";
    return 0;
}
