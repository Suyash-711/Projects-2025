#ifndef KDTREE_H
#define KDTREE_H

#include <vector>
#include <string>
#include <memory>

struct Point {
    std::vector<double> coords;
    int id;
    std::string name;
};

struct KDNode {
    Point point;
    std::unique_ptr<KDNode> left;
    std::unique_ptr<KDNode> right;
    int axis;
};

class KDTree {
public:
    KDTree(const std::vector<Point>& points, int dims);
    std::vector<Point> kNearest(const Point& target, int k);
    std::vector<Point> radiusSearch(const Point& target, double radius);
    std::vector<Point> rangeSearch(const std::vector<double>& minRange,
                                   const std::vector<double>& maxRange);
private:
    std::unique_ptr<KDNode> build(std::vector<Point> points, int depth);
    void kNearestRec(KDNode* node, const Point& target, int k,
                     std::vector<std::pair<double, Point>>& heap);
    void radiusSearchRec(KDNode* node, const Point& target, double radius,
                         std::vector<Point>& result);
    void rangeSearchRec(KDNode* node,
                        const std::vector<double>& minRange,
                        const std::vector<double>& maxRange,
                        std::vector<Point>& result);
    double distance(const Point& a, const Point& b);
    int dims;
    std::unique_ptr<KDNode> root;
};

#endif
